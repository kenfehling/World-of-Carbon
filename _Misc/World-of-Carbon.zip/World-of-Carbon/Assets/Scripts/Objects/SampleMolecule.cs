﻿using UnityEngine;
using System.Collections;

public class SampleMolecule : WorldObject {

	public string element;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
